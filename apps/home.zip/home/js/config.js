var url ="http://210.42.122.86/api/V1/";
TrunPage.pageInit();
