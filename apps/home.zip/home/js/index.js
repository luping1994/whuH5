var m_sign;

function loadPage() {
    getData();
}

function getData() {
    TrunPage.setProgressBarVisibility(true);
    TrunPage.getSignUser(function (data) {
        m_sign = data;
        $.ajax({
            url: url + '/Login',
            data: {'Sign': m_sign},
            type: 'POST',
            dataType: "json",
            success: function (json) {
                //初始化容器样式
                TrunPage.showToast(json.token.access_token);
            }
        });
    });

}

function getDetail() {
    TrunPage.openWebView("demo/www/infoDetail.html", 1, "信息详情");
}

