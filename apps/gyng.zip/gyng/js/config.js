// var url ="http://210.42.122.86/api/V1/";
var url ="https://xsydapp.whu.edu.cn/api/V1/";
TrunPage.pageInit();
